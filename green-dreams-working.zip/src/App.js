import React, { useState, useEffect } from "react";

const seeds = [
  {
    name: "Fruit Tree",
    cost: 10,
    reward: 2,
    fruitEmojis: ["🍏", "🍎", "🍎🍎", "🍎🍎🍎"],
    growTime: 30,
  },
];

const growthInterval = 1000;

export default function App() {
  const [garden, setGarden] = useState(Array(6).fill(null));
  const [coins, setCoins] = useState(20);
  const [selectedSeedIndex, setSelectedSeedIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setGarden((prevGarden) =>
        prevGarden.map((plot) => {
          if (!plot) return null;
          if (plot.fruitReady) return plot;
          const newProgress = plot.progress + 1;
          const growTime = seeds[plot.seedType].growTime;
          if (newProgress >= growTime) {
            return {
              ...plot,
              progress: 0,
              fruitReady: true,
              fruitSize: Math.floor(Math.random() * 3) + 1,
            };
          }
          return { ...plot, progress: newProgress };
        })
      );
    }, growthInterval);
    return () => clearInterval(interval);
  }, []);

  const plantSeed = (index) => {
    const seed = seeds[selectedSeedIndex];
    if (coins < seed.cost || garden[index]) return;
    setCoins(coins - seed.cost);
    const newPlot = {
      seedType: selectedSeedIndex,
      progress: 0,
      fruitReady: false,
      fruitSize: 1,
    };
    setGarden((g) => {
      const updated = [...g];
      updated[index] = newPlot;
      return updated;
    });
  };

  const waterPlant = (index) => {
    setGarden((g) => {
      const updated = [...g];
      if (updated[index] && !updated[index].fruitReady) {
        updated[index].progress += 5;
      }
      return updated;
    });
  };

  const harvestFruit = (index) => {
    setGarden((g) => {
      const updated = [...g];
      const plot = updated[index];
      if (plot && plot.fruitReady) {
        const reward = seeds[plot.seedType].reward * plot.fruitSize;
        setCoins((c) => c + reward);
        updated[index] = {
          ...plot,
          fruitReady: false,
          progress: 0,
        };
      }
      return updated;
    });
  };

  const clearPlot = (index) => {
    setGarden((g) => {
      const updated = [...g];
      updated[index] = null;
      return updated;
    });
  };

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif", textAlign: "center" }}>
      <h1>🌿 Green Dreams</h1>
      <p>Coins: {coins}</p>

      <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
        {seeds.map((seed, i) => (
          <button
            key={i}
            onClick={() => setSelectedSeedIndex(i)}
            style={{
              margin: 5,
              backgroundColor: selectedSeedIndex === i ? "#4CAF50" : "#81C784",
              color: "white",
              padding: "10px 15px",
              borderRadius: 8,
              border: "none",
              fontWeight: "bold",
            }}
          >
            {seed.name} ({seed.cost}💰)
          </button>
        ))}
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 100px)",
          gap: 10,
          justifyContent: "center",
        }}
      >
        {garden.map((plot, index) => {
          const seed = plot ? seeds[plot.seedType] : null;
          return (
            <div
              key={index}
              onClick={() =>
                plot ? (plot.fruitReady ? harvestFruit(index) : waterPlant(index)) : plantSeed(index)
              }
              onContextMenu={(e) => {
                e.preventDefault();
                clearPlot(index);
              }}
              style={{
                backgroundColor: "#C8E6C9",
                border: "2px solid #2E7D32",
                borderRadius: 10,
                width: 100,
                height: 100,
                fontSize: 28,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
                cursor: "pointer",
              }}
              title={plot ? (plot.fruitReady ? "Click to harvest!" : "Click to water") : "Click to plant"}
            >
              {plot ? (
                plot.fruitReady ? (
                  <span style={{ fontSize: 28 + plot.fruitSize * 4 }}>{seed.fruitEmojis[plot.fruitSize]}</span>
                ) : (
                  <div>
                    🌳
                    <div style={{ fontSize: 10 }}>
                      Growing: {Math.min(100, Math.floor((plot.progress / seed.growTime) * 100))}%
                    </div>
                  </div>
                )
              ) : (
                ""
              )}
            </div>
          );
        })}
      </div>

      <p style={{ fontSize: 12, marginTop: 20 }}>
        💧 Click a plot to water • 🌳 Grows over time • 🍎 Harvest fruit when ready • Right-click to clear
      </p>
    </div>
  );
}
